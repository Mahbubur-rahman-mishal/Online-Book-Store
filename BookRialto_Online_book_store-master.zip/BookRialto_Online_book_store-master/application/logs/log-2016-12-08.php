<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-08 20:55:18 --> Config Class Initialized
INFO - 2016-12-08 20:55:18 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:55:18 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:55:18 --> Utf8 Class Initialized
INFO - 2016-12-08 20:55:18 --> URI Class Initialized
INFO - 2016-12-08 20:55:18 --> Router Class Initialized
INFO - 2016-12-08 20:55:18 --> Output Class Initialized
INFO - 2016-12-08 20:55:18 --> Security Class Initialized
DEBUG - 2016-12-08 20:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:55:18 --> Input Class Initialized
INFO - 2016-12-08 20:55:18 --> Language Class Initialized
INFO - 2016-12-08 20:55:18 --> Loader Class Initialized
INFO - 2016-12-08 20:55:18 --> Controller Class Initialized
INFO - 2016-12-08 20:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:55:18 --> Helper loaded: form_helper
INFO - 2016-12-08 20:55:18 --> Helper loaded: url_helper
INFO - 2016-12-08 20:55:18 --> Helper loaded: html_helper
INFO - 2016-12-08 20:55:18 --> Database Driver Class Initialized
INFO - 2016-12-08 20:55:18 --> Model Class Initialized
INFO - 2016-12-08 20:55:18 --> Model Class Initialized
ERROR - 2016-12-08 20:55:18 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-08 20:55:18 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-08 20:55:18 --> File loaded: C:\xampp\htdocs\Library\application\views\allUser_view.php
INFO - 2016-12-08 20:55:18 --> Final output sent to browser
DEBUG - 2016-12-08 20:55:18 --> Total execution time: 0.1043
INFO - 2016-12-08 20:55:21 --> Config Class Initialized
INFO - 2016-12-08 20:55:21 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:55:21 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:55:21 --> Utf8 Class Initialized
INFO - 2016-12-08 20:55:21 --> URI Class Initialized
INFO - 2016-12-08 20:55:21 --> Router Class Initialized
INFO - 2016-12-08 20:55:21 --> Output Class Initialized
INFO - 2016-12-08 20:55:21 --> Security Class Initialized
DEBUG - 2016-12-08 20:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:55:21 --> Input Class Initialized
INFO - 2016-12-08 20:55:21 --> Language Class Initialized
INFO - 2016-12-08 20:55:21 --> Loader Class Initialized
INFO - 2016-12-08 20:55:21 --> Controller Class Initialized
INFO - 2016-12-08 20:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:55:22 --> Helper loaded: form_helper
INFO - 2016-12-08 20:55:22 --> Helper loaded: url_helper
INFO - 2016-12-08 20:55:22 --> Helper loaded: html_helper
INFO - 2016-12-08 20:55:22 --> Database Driver Class Initialized
INFO - 2016-12-08 20:55:22 --> Model Class Initialized
INFO - 2016-12-08 20:55:22 --> Model Class Initialized
INFO - 2016-12-08 20:55:22 --> Final output sent to browser
DEBUG - 2016-12-08 20:55:22 --> Total execution time: 0.0679
INFO - 2016-12-08 20:55:26 --> Config Class Initialized
INFO - 2016-12-08 20:55:26 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:55:26 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:55:26 --> Utf8 Class Initialized
INFO - 2016-12-08 20:55:26 --> URI Class Initialized
INFO - 2016-12-08 20:55:26 --> Router Class Initialized
INFO - 2016-12-08 20:55:26 --> Output Class Initialized
INFO - 2016-12-08 20:55:26 --> Security Class Initialized
DEBUG - 2016-12-08 20:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:55:26 --> Input Class Initialized
INFO - 2016-12-08 20:55:26 --> Language Class Initialized
INFO - 2016-12-08 20:55:26 --> Loader Class Initialized
INFO - 2016-12-08 20:55:26 --> Controller Class Initialized
INFO - 2016-12-08 20:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:55:26 --> Helper loaded: form_helper
INFO - 2016-12-08 20:55:26 --> Helper loaded: url_helper
INFO - 2016-12-08 20:55:26 --> Helper loaded: html_helper
INFO - 2016-12-08 20:55:26 --> Database Driver Class Initialized
INFO - 2016-12-08 20:55:26 --> Model Class Initialized
INFO - 2016-12-08 20:55:26 --> Model Class Initialized
INFO - 2016-12-08 20:55:26 --> Final output sent to browser
DEBUG - 2016-12-08 20:55:26 --> Total execution time: 0.0680
INFO - 2016-12-08 20:55:28 --> Config Class Initialized
INFO - 2016-12-08 20:55:28 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:55:28 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:55:28 --> Utf8 Class Initialized
INFO - 2016-12-08 20:55:28 --> URI Class Initialized
INFO - 2016-12-08 20:55:28 --> Router Class Initialized
INFO - 2016-12-08 20:55:28 --> Output Class Initialized
INFO - 2016-12-08 20:55:28 --> Security Class Initialized
DEBUG - 2016-12-08 20:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:55:28 --> Input Class Initialized
INFO - 2016-12-08 20:55:28 --> Language Class Initialized
INFO - 2016-12-08 20:55:28 --> Loader Class Initialized
INFO - 2016-12-08 20:55:28 --> Controller Class Initialized
INFO - 2016-12-08 20:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:55:28 --> Helper loaded: form_helper
INFO - 2016-12-08 20:55:28 --> Helper loaded: url_helper
INFO - 2016-12-08 20:55:28 --> Helper loaded: html_helper
INFO - 2016-12-08 20:55:28 --> Database Driver Class Initialized
INFO - 2016-12-08 20:55:28 --> Model Class Initialized
INFO - 2016-12-08 20:55:28 --> Model Class Initialized
INFO - 2016-12-08 20:55:28 --> Final output sent to browser
DEBUG - 2016-12-08 20:55:28 --> Total execution time: 0.1087
INFO - 2016-12-08 20:55:30 --> Config Class Initialized
INFO - 2016-12-08 20:55:30 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:55:30 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:55:30 --> Utf8 Class Initialized
INFO - 2016-12-08 20:55:30 --> URI Class Initialized
INFO - 2016-12-08 20:55:30 --> Router Class Initialized
INFO - 2016-12-08 20:55:30 --> Output Class Initialized
INFO - 2016-12-08 20:55:30 --> Security Class Initialized
DEBUG - 2016-12-08 20:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:55:30 --> Input Class Initialized
INFO - 2016-12-08 20:55:30 --> Language Class Initialized
INFO - 2016-12-08 20:55:30 --> Loader Class Initialized
INFO - 2016-12-08 20:55:30 --> Controller Class Initialized
INFO - 2016-12-08 20:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:55:30 --> Helper loaded: form_helper
INFO - 2016-12-08 20:55:30 --> Helper loaded: url_helper
INFO - 2016-12-08 20:55:30 --> Helper loaded: html_helper
INFO - 2016-12-08 20:55:30 --> Database Driver Class Initialized
INFO - 2016-12-08 20:55:30 --> Model Class Initialized
INFO - 2016-12-08 20:55:30 --> Model Class Initialized
ERROR - 2016-12-08 20:55:30 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-08 20:55:30 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-08 20:55:30 --> File loaded: C:\xampp\htdocs\Library\application\views\allUser_view.php
INFO - 2016-12-08 20:55:30 --> Final output sent to browser
DEBUG - 2016-12-08 20:55:30 --> Total execution time: 0.1127
INFO - 2016-12-08 20:55:35 --> Config Class Initialized
INFO - 2016-12-08 20:55:35 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:55:35 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:55:35 --> Utf8 Class Initialized
INFO - 2016-12-08 20:55:35 --> URI Class Initialized
INFO - 2016-12-08 20:55:35 --> Router Class Initialized
INFO - 2016-12-08 20:55:35 --> Output Class Initialized
INFO - 2016-12-08 20:55:35 --> Security Class Initialized
DEBUG - 2016-12-08 20:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:55:35 --> Input Class Initialized
INFO - 2016-12-08 20:55:35 --> Language Class Initialized
INFO - 2016-12-08 20:55:35 --> Loader Class Initialized
INFO - 2016-12-08 20:55:35 --> Controller Class Initialized
INFO - 2016-12-08 20:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:55:35 --> Helper loaded: form_helper
INFO - 2016-12-08 20:55:35 --> Helper loaded: url_helper
INFO - 2016-12-08 20:55:35 --> Helper loaded: html_helper
INFO - 2016-12-08 20:55:35 --> Database Driver Class Initialized
INFO - 2016-12-08 20:55:35 --> Model Class Initialized
INFO - 2016-12-08 20:55:35 --> Model Class Initialized
INFO - 2016-12-08 20:55:35 --> Final output sent to browser
DEBUG - 2016-12-08 20:55:35 --> Total execution time: 0.1393
INFO - 2016-12-08 20:55:35 --> Config Class Initialized
INFO - 2016-12-08 20:55:35 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:55:35 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:55:35 --> Utf8 Class Initialized
INFO - 2016-12-08 20:55:35 --> URI Class Initialized
INFO - 2016-12-08 20:55:35 --> Router Class Initialized
INFO - 2016-12-08 20:55:35 --> Output Class Initialized
INFO - 2016-12-08 20:55:35 --> Security Class Initialized
DEBUG - 2016-12-08 20:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:55:35 --> Input Class Initialized
INFO - 2016-12-08 20:55:35 --> Language Class Initialized
INFO - 2016-12-08 20:55:35 --> Loader Class Initialized
INFO - 2016-12-08 20:55:35 --> Controller Class Initialized
INFO - 2016-12-08 20:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:55:35 --> Helper loaded: form_helper
INFO - 2016-12-08 20:55:35 --> Helper loaded: url_helper
INFO - 2016-12-08 20:55:35 --> Helper loaded: html_helper
INFO - 2016-12-08 20:55:35 --> Database Driver Class Initialized
INFO - 2016-12-08 20:55:35 --> Model Class Initialized
INFO - 2016-12-08 20:55:35 --> Model Class Initialized
INFO - 2016-12-08 20:55:35 --> Final output sent to browser
DEBUG - 2016-12-08 20:55:35 --> Total execution time: 0.1472
INFO - 2016-12-08 20:56:27 --> Config Class Initialized
INFO - 2016-12-08 20:56:27 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:56:27 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:56:27 --> Utf8 Class Initialized
INFO - 2016-12-08 20:56:27 --> URI Class Initialized
INFO - 2016-12-08 20:56:27 --> Router Class Initialized
INFO - 2016-12-08 20:56:27 --> Output Class Initialized
INFO - 2016-12-08 20:56:27 --> Security Class Initialized
DEBUG - 2016-12-08 20:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:56:27 --> Input Class Initialized
INFO - 2016-12-08 20:56:27 --> Language Class Initialized
INFO - 2016-12-08 20:56:27 --> Loader Class Initialized
INFO - 2016-12-08 20:56:27 --> Controller Class Initialized
INFO - 2016-12-08 20:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:56:27 --> Helper loaded: form_helper
INFO - 2016-12-08 20:56:27 --> Helper loaded: url_helper
INFO - 2016-12-08 20:56:27 --> Helper loaded: html_helper
INFO - 2016-12-08 20:56:27 --> Database Driver Class Initialized
INFO - 2016-12-08 20:56:27 --> Form Validation Class Initialized
INFO - 2016-12-08 20:56:27 --> Model Class Initialized
INFO - 2016-12-08 20:56:27 --> Model Class Initialized
INFO - 2016-12-08 20:56:27 --> Config Class Initialized
INFO - 2016-12-08 20:56:27 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:56:27 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:56:27 --> Utf8 Class Initialized
INFO - 2016-12-08 20:56:27 --> URI Class Initialized
INFO - 2016-12-08 20:56:27 --> Router Class Initialized
INFO - 2016-12-08 20:56:27 --> Output Class Initialized
INFO - 2016-12-08 20:56:27 --> Security Class Initialized
DEBUG - 2016-12-08 20:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:56:27 --> Input Class Initialized
INFO - 2016-12-08 20:56:27 --> Language Class Initialized
INFO - 2016-12-08 20:56:27 --> Loader Class Initialized
INFO - 2016-12-08 20:56:27 --> Controller Class Initialized
INFO - 2016-12-08 20:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:56:27 --> Helper loaded: form_helper
INFO - 2016-12-08 20:56:27 --> Helper loaded: url_helper
INFO - 2016-12-08 20:56:27 --> Helper loaded: html_helper
INFO - 2016-12-08 20:56:27 --> Database Driver Class Initialized
INFO - 2016-12-08 20:56:27 --> Form Validation Class Initialized
INFO - 2016-12-08 20:56:27 --> Model Class Initialized
INFO - 2016-12-08 20:56:27 --> Model Class Initialized
INFO - 2016-12-08 20:56:27 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-08 20:56:27 --> File loaded: C:\xampp\htdocs\Library\application\views\login_view.php
INFO - 2016-12-08 20:56:27 --> Final output sent to browser
DEBUG - 2016-12-08 20:56:27 --> Total execution time: 0.1927
INFO - 2016-12-08 20:56:33 --> Config Class Initialized
INFO - 2016-12-08 20:56:33 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:56:33 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:56:33 --> Utf8 Class Initialized
INFO - 2016-12-08 20:56:33 --> URI Class Initialized
INFO - 2016-12-08 20:56:33 --> Router Class Initialized
INFO - 2016-12-08 20:56:33 --> Output Class Initialized
INFO - 2016-12-08 20:56:33 --> Security Class Initialized
DEBUG - 2016-12-08 20:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:56:33 --> Input Class Initialized
INFO - 2016-12-08 20:56:33 --> Language Class Initialized
INFO - 2016-12-08 20:56:33 --> Loader Class Initialized
INFO - 2016-12-08 20:56:33 --> Controller Class Initialized
INFO - 2016-12-08 20:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:56:33 --> Helper loaded: form_helper
INFO - 2016-12-08 20:56:33 --> Helper loaded: url_helper
INFO - 2016-12-08 20:56:33 --> Helper loaded: html_helper
INFO - 2016-12-08 20:56:33 --> Database Driver Class Initialized
INFO - 2016-12-08 20:56:33 --> Form Validation Class Initialized
INFO - 2016-12-08 20:56:33 --> Model Class Initialized
INFO - 2016-12-08 20:56:33 --> Model Class Initialized
INFO - 2016-12-08 20:56:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-08 20:56:33 --> Config Class Initialized
INFO - 2016-12-08 20:56:33 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:56:33 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:56:33 --> Utf8 Class Initialized
INFO - 2016-12-08 20:56:33 --> URI Class Initialized
INFO - 2016-12-08 20:56:33 --> Router Class Initialized
INFO - 2016-12-08 20:56:33 --> Output Class Initialized
INFO - 2016-12-08 20:56:33 --> Security Class Initialized
DEBUG - 2016-12-08 20:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:56:33 --> Input Class Initialized
INFO - 2016-12-08 20:56:33 --> Language Class Initialized
INFO - 2016-12-08 20:56:33 --> Loader Class Initialized
INFO - 2016-12-08 20:56:33 --> Controller Class Initialized
INFO - 2016-12-08 20:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:56:33 --> Helper loaded: form_helper
INFO - 2016-12-08 20:56:33 --> Helper loaded: url_helper
INFO - 2016-12-08 20:56:33 --> Helper loaded: html_helper
INFO - 2016-12-08 20:56:33 --> Database Driver Class Initialized
INFO - 2016-12-08 20:56:33 --> Model Class Initialized
INFO - 2016-12-08 20:56:33 --> Model Class Initialized
ERROR - 2016-12-08 20:56:33 --> 29
INFO - 2016-12-08 20:56:33 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-08 20:56:33 --> File loaded: C:\xampp\htdocs\Library\application\views\dashboard_view.php
INFO - 2016-12-08 20:56:33 --> Final output sent to browser
DEBUG - 2016-12-08 20:56:33 --> Total execution time: 0.0835
INFO - 2016-12-08 20:56:38 --> Config Class Initialized
INFO - 2016-12-08 20:56:38 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:56:38 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:56:38 --> Utf8 Class Initialized
INFO - 2016-12-08 20:56:38 --> URI Class Initialized
INFO - 2016-12-08 20:56:38 --> Router Class Initialized
INFO - 2016-12-08 20:56:38 --> Output Class Initialized
INFO - 2016-12-08 20:56:38 --> Security Class Initialized
DEBUG - 2016-12-08 20:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:56:38 --> Input Class Initialized
INFO - 2016-12-08 20:56:38 --> Language Class Initialized
INFO - 2016-12-08 20:56:38 --> Loader Class Initialized
INFO - 2016-12-08 20:56:38 --> Controller Class Initialized
INFO - 2016-12-08 20:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:56:38 --> Helper loaded: form_helper
INFO - 2016-12-08 20:56:38 --> Helper loaded: url_helper
INFO - 2016-12-08 20:56:38 --> Helper loaded: html_helper
INFO - 2016-12-08 20:56:38 --> Database Driver Class Initialized
INFO - 2016-12-08 20:56:38 --> Model Class Initialized
INFO - 2016-12-08 20:56:38 --> Model Class Initialized
INFO - 2016-12-08 20:56:38 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-08 20:56:38 --> File loaded: C:\xampp\htdocs\Library\application\views\lendOrBuyBooks_view.php
INFO - 2016-12-08 20:56:38 --> Final output sent to browser
DEBUG - 2016-12-08 20:56:38 --> Total execution time: 0.1025
INFO - 2016-12-08 20:56:44 --> Config Class Initialized
INFO - 2016-12-08 20:56:44 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:56:44 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:56:44 --> Utf8 Class Initialized
INFO - 2016-12-08 20:56:44 --> URI Class Initialized
INFO - 2016-12-08 20:56:44 --> Router Class Initialized
INFO - 2016-12-08 20:56:44 --> Output Class Initialized
INFO - 2016-12-08 20:56:44 --> Security Class Initialized
DEBUG - 2016-12-08 20:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:56:44 --> Input Class Initialized
INFO - 2016-12-08 20:56:44 --> Language Class Initialized
INFO - 2016-12-08 20:56:44 --> Loader Class Initialized
INFO - 2016-12-08 20:56:44 --> Controller Class Initialized
INFO - 2016-12-08 20:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:56:44 --> Helper loaded: form_helper
INFO - 2016-12-08 20:56:44 --> Helper loaded: url_helper
INFO - 2016-12-08 20:56:44 --> Helper loaded: html_helper
INFO - 2016-12-08 20:56:44 --> Database Driver Class Initialized
INFO - 2016-12-08 20:56:44 --> Model Class Initialized
INFO - 2016-12-08 20:56:44 --> Model Class Initialized
INFO - 2016-12-08 20:56:44 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-08 20:56:44 --> File loaded: C:\xampp\htdocs\Library\application\views\request_of_books_view.php
INFO - 2016-12-08 20:56:44 --> Final output sent to browser
DEBUG - 2016-12-08 20:56:44 --> Total execution time: 0.1086
INFO - 2016-12-08 20:58:20 --> Config Class Initialized
INFO - 2016-12-08 20:58:20 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:58:20 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:58:20 --> Utf8 Class Initialized
INFO - 2016-12-08 20:58:20 --> URI Class Initialized
INFO - 2016-12-08 20:58:20 --> Router Class Initialized
INFO - 2016-12-08 20:58:20 --> Output Class Initialized
INFO - 2016-12-08 20:58:20 --> Security Class Initialized
DEBUG - 2016-12-08 20:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:58:20 --> Input Class Initialized
INFO - 2016-12-08 20:58:20 --> Language Class Initialized
INFO - 2016-12-08 20:58:20 --> Loader Class Initialized
INFO - 2016-12-08 20:58:20 --> Controller Class Initialized
INFO - 2016-12-08 20:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:58:20 --> Helper loaded: form_helper
INFO - 2016-12-08 20:58:20 --> Helper loaded: url_helper
INFO - 2016-12-08 20:58:20 --> Helper loaded: html_helper
INFO - 2016-12-08 20:58:20 --> Database Driver Class Initialized
INFO - 2016-12-08 20:58:20 --> Form Validation Class Initialized
INFO - 2016-12-08 20:58:20 --> Model Class Initialized
INFO - 2016-12-08 20:58:20 --> Model Class Initialized
INFO - 2016-12-08 20:58:20 --> Config Class Initialized
INFO - 2016-12-08 20:58:20 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:58:20 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:58:20 --> Utf8 Class Initialized
INFO - 2016-12-08 20:58:20 --> URI Class Initialized
INFO - 2016-12-08 20:58:20 --> Router Class Initialized
INFO - 2016-12-08 20:58:20 --> Output Class Initialized
INFO - 2016-12-08 20:58:20 --> Security Class Initialized
DEBUG - 2016-12-08 20:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:58:20 --> Input Class Initialized
INFO - 2016-12-08 20:58:20 --> Language Class Initialized
INFO - 2016-12-08 20:58:20 --> Loader Class Initialized
INFO - 2016-12-08 20:58:20 --> Controller Class Initialized
INFO - 2016-12-08 20:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:58:20 --> Helper loaded: form_helper
INFO - 2016-12-08 20:58:20 --> Helper loaded: url_helper
INFO - 2016-12-08 20:58:20 --> Helper loaded: html_helper
INFO - 2016-12-08 20:58:20 --> Database Driver Class Initialized
INFO - 2016-12-08 20:58:20 --> Form Validation Class Initialized
INFO - 2016-12-08 20:58:20 --> Model Class Initialized
INFO - 2016-12-08 20:58:20 --> Model Class Initialized
INFO - 2016-12-08 20:58:20 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-08 20:58:20 --> File loaded: C:\xampp\htdocs\Library\application\views\login_view.php
INFO - 2016-12-08 20:58:20 --> Final output sent to browser
DEBUG - 2016-12-08 20:58:20 --> Total execution time: 0.0983
INFO - 2016-12-08 20:58:26 --> Config Class Initialized
INFO - 2016-12-08 20:58:26 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:58:26 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:58:26 --> Utf8 Class Initialized
INFO - 2016-12-08 20:58:26 --> URI Class Initialized
INFO - 2016-12-08 20:58:26 --> Router Class Initialized
INFO - 2016-12-08 20:58:26 --> Output Class Initialized
INFO - 2016-12-08 20:58:26 --> Security Class Initialized
DEBUG - 2016-12-08 20:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:58:26 --> Input Class Initialized
INFO - 2016-12-08 20:58:26 --> Language Class Initialized
INFO - 2016-12-08 20:58:26 --> Loader Class Initialized
INFO - 2016-12-08 20:58:26 --> Controller Class Initialized
INFO - 2016-12-08 20:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:58:26 --> Helper loaded: form_helper
INFO - 2016-12-08 20:58:26 --> Helper loaded: url_helper
INFO - 2016-12-08 20:58:26 --> Helper loaded: html_helper
INFO - 2016-12-08 20:58:26 --> Database Driver Class Initialized
INFO - 2016-12-08 20:58:27 --> Model Class Initialized
INFO - 2016-12-08 20:58:27 --> Model Class Initialized
ERROR - 2016-12-08 20:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Library\application\views\header_view.php 166
ERROR - 2016-12-08 20:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Library\application\views\header_view.php 180
ERROR - 2016-12-08 20:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Library\application\views\header_view.php 193
INFO - 2016-12-08 20:58:27 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-08 20:58:27 --> File loaded: C:\xampp\htdocs\Library\application\views\message_view.php
INFO - 2016-12-08 20:58:27 --> Final output sent to browser
DEBUG - 2016-12-08 20:58:27 --> Total execution time: 0.1772
INFO - 2016-12-08 20:58:31 --> Config Class Initialized
INFO - 2016-12-08 20:58:31 --> Hooks Class Initialized
DEBUG - 2016-12-08 20:58:31 --> UTF-8 Support Enabled
INFO - 2016-12-08 20:58:31 --> Utf8 Class Initialized
INFO - 2016-12-08 20:58:31 --> URI Class Initialized
INFO - 2016-12-08 20:58:31 --> Router Class Initialized
INFO - 2016-12-08 20:58:31 --> Output Class Initialized
INFO - 2016-12-08 20:58:31 --> Security Class Initialized
DEBUG - 2016-12-08 20:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-08 20:58:31 --> Input Class Initialized
INFO - 2016-12-08 20:58:31 --> Language Class Initialized
INFO - 2016-12-08 20:58:31 --> Loader Class Initialized
INFO - 2016-12-08 20:58:31 --> Controller Class Initialized
INFO - 2016-12-08 20:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-08 20:58:31 --> Helper loaded: form_helper
INFO - 2016-12-08 20:58:31 --> Helper loaded: url_helper
INFO - 2016-12-08 20:58:31 --> Helper loaded: html_helper
INFO - 2016-12-08 20:58:31 --> Database Driver Class Initialized
INFO - 2016-12-08 20:58:31 --> Model Class Initialized
INFO - 2016-12-08 20:58:31 --> Model Class Initialized
INFO - 2016-12-08 20:58:31 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-08 20:58:31 --> File loaded: C:\xampp\htdocs\Library\application\views\login_view.php
INFO - 2016-12-08 20:58:31 --> Final output sent to browser
DEBUG - 2016-12-08 20:58:31 --> Total execution time: 0.0856
