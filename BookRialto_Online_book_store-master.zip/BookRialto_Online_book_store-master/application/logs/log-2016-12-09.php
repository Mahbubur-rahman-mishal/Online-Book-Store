<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-09 08:18:55 --> Config Class Initialized
INFO - 2016-12-09 08:18:55 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:18:55 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:18:55 --> Utf8 Class Initialized
INFO - 2016-12-09 08:18:55 --> URI Class Initialized
DEBUG - 2016-12-09 08:18:55 --> No URI present. Default controller set.
INFO - 2016-12-09 08:18:55 --> Router Class Initialized
INFO - 2016-12-09 08:18:55 --> Output Class Initialized
INFO - 2016-12-09 08:18:55 --> Security Class Initialized
DEBUG - 2016-12-09 08:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:18:55 --> Input Class Initialized
INFO - 2016-12-09 08:18:55 --> Language Class Initialized
INFO - 2016-12-09 08:18:55 --> Loader Class Initialized
INFO - 2016-12-09 08:18:55 --> Controller Class Initialized
INFO - 2016-12-09 08:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:18:55 --> Helper loaded: url_helper
INFO - 2016-12-09 08:18:55 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 08:18:55 --> File loaded: C:\xampp\htdocs\Library\application\views\footer_view.php
INFO - 2016-12-09 08:18:55 --> File loaded: C:\xampp\htdocs\Library\application\views\home_view.php
INFO - 2016-12-09 08:18:55 --> Final output sent to browser
DEBUG - 2016-12-09 08:18:55 --> Total execution time: 0.3932
INFO - 2016-12-09 08:19:00 --> Config Class Initialized
INFO - 2016-12-09 08:19:00 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:19:00 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:19:00 --> Utf8 Class Initialized
INFO - 2016-12-09 08:19:00 --> URI Class Initialized
INFO - 2016-12-09 08:19:00 --> Router Class Initialized
INFO - 2016-12-09 08:19:00 --> Output Class Initialized
INFO - 2016-12-09 08:19:00 --> Security Class Initialized
DEBUG - 2016-12-09 08:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:19:00 --> Input Class Initialized
INFO - 2016-12-09 08:19:00 --> Language Class Initialized
INFO - 2016-12-09 08:19:00 --> Loader Class Initialized
INFO - 2016-12-09 08:19:00 --> Controller Class Initialized
INFO - 2016-12-09 08:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:19:01 --> Helper loaded: form_helper
INFO - 2016-12-09 08:19:01 --> Helper loaded: url_helper
INFO - 2016-12-09 08:19:01 --> Helper loaded: html_helper
INFO - 2016-12-09 08:19:01 --> Database Driver Class Initialized
INFO - 2016-12-09 08:19:01 --> Form Validation Class Initialized
INFO - 2016-12-09 08:19:01 --> Model Class Initialized
INFO - 2016-12-09 08:19:01 --> Model Class Initialized
INFO - 2016-12-09 08:19:01 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 08:19:01 --> File loaded: C:\xampp\htdocs\Library\application\views\login_view.php
INFO - 2016-12-09 08:19:01 --> Final output sent to browser
DEBUG - 2016-12-09 08:19:01 --> Total execution time: 0.2901
INFO - 2016-12-09 08:19:05 --> Config Class Initialized
INFO - 2016-12-09 08:19:05 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:19:05 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:19:05 --> Utf8 Class Initialized
INFO - 2016-12-09 08:19:05 --> URI Class Initialized
INFO - 2016-12-09 08:19:05 --> Router Class Initialized
INFO - 2016-12-09 08:19:05 --> Output Class Initialized
INFO - 2016-12-09 08:19:05 --> Security Class Initialized
DEBUG - 2016-12-09 08:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:19:05 --> Input Class Initialized
INFO - 2016-12-09 08:19:05 --> Language Class Initialized
INFO - 2016-12-09 08:19:05 --> Loader Class Initialized
INFO - 2016-12-09 08:19:05 --> Controller Class Initialized
INFO - 2016-12-09 08:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:19:05 --> Helper loaded: form_helper
INFO - 2016-12-09 08:19:05 --> Helper loaded: url_helper
INFO - 2016-12-09 08:19:05 --> Helper loaded: html_helper
INFO - 2016-12-09 08:19:05 --> Database Driver Class Initialized
INFO - 2016-12-09 08:19:05 --> Form Validation Class Initialized
INFO - 2016-12-09 08:19:05 --> Model Class Initialized
INFO - 2016-12-09 08:19:05 --> Model Class Initialized
INFO - 2016-12-09 08:19:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-09 08:19:06 --> Config Class Initialized
INFO - 2016-12-09 08:19:06 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:19:06 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:19:06 --> Utf8 Class Initialized
INFO - 2016-12-09 08:19:06 --> URI Class Initialized
INFO - 2016-12-09 08:19:06 --> Router Class Initialized
INFO - 2016-12-09 08:19:06 --> Output Class Initialized
INFO - 2016-12-09 08:19:06 --> Security Class Initialized
DEBUG - 2016-12-09 08:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:19:06 --> Input Class Initialized
INFO - 2016-12-09 08:19:06 --> Language Class Initialized
INFO - 2016-12-09 08:19:06 --> Loader Class Initialized
INFO - 2016-12-09 08:19:06 --> Controller Class Initialized
INFO - 2016-12-09 08:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:19:06 --> Helper loaded: form_helper
INFO - 2016-12-09 08:19:06 --> Helper loaded: url_helper
INFO - 2016-12-09 08:19:06 --> Helper loaded: html_helper
INFO - 2016-12-09 08:19:06 --> Database Driver Class Initialized
INFO - 2016-12-09 08:19:06 --> Model Class Initialized
INFO - 2016-12-09 08:19:06 --> Model Class Initialized
ERROR - 2016-12-09 08:19:06 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 08:19:06 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 08:19:06 --> File loaded: C:\xampp\htdocs\Library\application\views\admin_view.php
INFO - 2016-12-09 08:19:06 --> Final output sent to browser
DEBUG - 2016-12-09 08:19:06 --> Total execution time: 0.1401
INFO - 2016-12-09 08:19:09 --> Config Class Initialized
INFO - 2016-12-09 08:19:09 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:19:09 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:19:09 --> Utf8 Class Initialized
INFO - 2016-12-09 08:19:09 --> URI Class Initialized
INFO - 2016-12-09 08:19:09 --> Router Class Initialized
INFO - 2016-12-09 08:19:09 --> Output Class Initialized
INFO - 2016-12-09 08:19:09 --> Security Class Initialized
DEBUG - 2016-12-09 08:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:19:09 --> Input Class Initialized
INFO - 2016-12-09 08:19:09 --> Language Class Initialized
INFO - 2016-12-09 08:19:09 --> Loader Class Initialized
INFO - 2016-12-09 08:19:09 --> Controller Class Initialized
INFO - 2016-12-09 08:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:19:09 --> Helper loaded: form_helper
INFO - 2016-12-09 08:19:09 --> Helper loaded: url_helper
INFO - 2016-12-09 08:19:09 --> Helper loaded: html_helper
INFO - 2016-12-09 08:19:09 --> Database Driver Class Initialized
INFO - 2016-12-09 08:19:09 --> Model Class Initialized
INFO - 2016-12-09 08:19:09 --> Model Class Initialized
ERROR - 2016-12-09 08:19:09 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 08:19:09 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 08:19:09 --> File loaded: C:\xampp\htdocs\Library\application\views\allUser_view.php
INFO - 2016-12-09 08:19:09 --> Final output sent to browser
DEBUG - 2016-12-09 08:19:09 --> Total execution time: 0.1798
INFO - 2016-12-09 08:19:16 --> Config Class Initialized
INFO - 2016-12-09 08:19:16 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:19:16 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:19:16 --> Utf8 Class Initialized
INFO - 2016-12-09 08:19:16 --> URI Class Initialized
INFO - 2016-12-09 08:19:16 --> Router Class Initialized
INFO - 2016-12-09 08:19:16 --> Output Class Initialized
INFO - 2016-12-09 08:19:16 --> Security Class Initialized
DEBUG - 2016-12-09 08:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:19:16 --> Input Class Initialized
INFO - 2016-12-09 08:19:16 --> Language Class Initialized
INFO - 2016-12-09 08:19:16 --> Loader Class Initialized
INFO - 2016-12-09 08:19:16 --> Controller Class Initialized
INFO - 2016-12-09 08:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:19:16 --> Helper loaded: form_helper
INFO - 2016-12-09 08:19:16 --> Helper loaded: url_helper
INFO - 2016-12-09 08:19:16 --> Helper loaded: html_helper
INFO - 2016-12-09 08:19:16 --> Database Driver Class Initialized
INFO - 2016-12-09 08:19:16 --> Model Class Initialized
INFO - 2016-12-09 08:19:16 --> Model Class Initialized
ERROR - 2016-12-09 08:19:17 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 08:19:17 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 08:19:17 --> File loaded: C:\xampp\htdocs\Library\application\views\allBook_view.php
INFO - 2016-12-09 08:19:17 --> Final output sent to browser
DEBUG - 2016-12-09 08:19:17 --> Total execution time: 0.1474
INFO - 2016-12-09 08:19:28 --> Config Class Initialized
INFO - 2016-12-09 08:19:28 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:19:28 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:19:28 --> Utf8 Class Initialized
INFO - 2016-12-09 08:19:28 --> URI Class Initialized
INFO - 2016-12-09 08:19:28 --> Router Class Initialized
INFO - 2016-12-09 08:19:28 --> Output Class Initialized
INFO - 2016-12-09 08:19:28 --> Security Class Initialized
DEBUG - 2016-12-09 08:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:19:28 --> Input Class Initialized
INFO - 2016-12-09 08:19:28 --> Language Class Initialized
INFO - 2016-12-09 08:19:28 --> Loader Class Initialized
INFO - 2016-12-09 08:19:28 --> Controller Class Initialized
INFO - 2016-12-09 08:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:19:28 --> Helper loaded: form_helper
INFO - 2016-12-09 08:19:28 --> Helper loaded: url_helper
INFO - 2016-12-09 08:19:28 --> Helper loaded: html_helper
INFO - 2016-12-09 08:19:28 --> Database Driver Class Initialized
INFO - 2016-12-09 08:19:28 --> Model Class Initialized
INFO - 2016-12-09 08:19:28 --> Model Class Initialized
INFO - 2016-12-09 08:19:28 --> Final output sent to browser
DEBUG - 2016-12-09 08:19:28 --> Total execution time: 0.0769
INFO - 2016-12-09 08:19:28 --> Config Class Initialized
INFO - 2016-12-09 08:19:28 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:19:28 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:19:28 --> Utf8 Class Initialized
INFO - 2016-12-09 08:19:28 --> URI Class Initialized
INFO - 2016-12-09 08:19:28 --> Router Class Initialized
INFO - 2016-12-09 08:19:28 --> Output Class Initialized
INFO - 2016-12-09 08:19:28 --> Security Class Initialized
DEBUG - 2016-12-09 08:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:19:28 --> Input Class Initialized
INFO - 2016-12-09 08:19:28 --> Language Class Initialized
INFO - 2016-12-09 08:19:28 --> Loader Class Initialized
INFO - 2016-12-09 08:19:28 --> Controller Class Initialized
INFO - 2016-12-09 08:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:19:28 --> Helper loaded: form_helper
INFO - 2016-12-09 08:19:28 --> Helper loaded: url_helper
INFO - 2016-12-09 08:19:28 --> Helper loaded: html_helper
INFO - 2016-12-09 08:19:29 --> Database Driver Class Initialized
INFO - 2016-12-09 08:19:29 --> Model Class Initialized
INFO - 2016-12-09 08:19:29 --> Model Class Initialized
INFO - 2016-12-09 08:19:29 --> Final output sent to browser
DEBUG - 2016-12-09 08:19:29 --> Total execution time: 0.0769
INFO - 2016-12-09 08:19:37 --> Config Class Initialized
INFO - 2016-12-09 08:19:37 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:19:37 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:19:37 --> Utf8 Class Initialized
INFO - 2016-12-09 08:19:37 --> URI Class Initialized
INFO - 2016-12-09 08:19:37 --> Router Class Initialized
INFO - 2016-12-09 08:19:37 --> Output Class Initialized
INFO - 2016-12-09 08:19:37 --> Security Class Initialized
DEBUG - 2016-12-09 08:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:19:37 --> Input Class Initialized
INFO - 2016-12-09 08:19:37 --> Language Class Initialized
INFO - 2016-12-09 08:19:37 --> Loader Class Initialized
INFO - 2016-12-09 08:19:37 --> Controller Class Initialized
INFO - 2016-12-09 08:19:37 --> Model Class Initialized
INFO - 2016-12-09 08:19:37 --> Database Driver Class Initialized
INFO - 2016-12-09 08:19:37 --> Helper loaded: form_helper
INFO - 2016-12-09 08:19:37 --> Form Validation Class Initialized
INFO - 2016-12-09 08:19:37 --> Helper loaded: url_helper
INFO - 2016-12-09 08:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:19:37 --> Model Class Initialized
INFO - 2016-12-09 08:19:37 --> Model Class Initialized
ERROR - 2016-12-09 08:19:37 --> Android Alpha
ERROR - 2016-12-09 08:19:37 --> Android Alpha
INFO - 2016-12-09 08:19:37 --> Final output sent to browser
DEBUG - 2016-12-09 08:19:37 --> Total execution time: 0.0663
INFO - 2016-12-09 08:19:43 --> Config Class Initialized
INFO - 2016-12-09 08:19:43 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:19:43 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:19:43 --> Utf8 Class Initialized
INFO - 2016-12-09 08:19:43 --> URI Class Initialized
INFO - 2016-12-09 08:19:43 --> Router Class Initialized
INFO - 2016-12-09 08:19:43 --> Output Class Initialized
INFO - 2016-12-09 08:19:43 --> Security Class Initialized
DEBUG - 2016-12-09 08:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:19:43 --> Input Class Initialized
INFO - 2016-12-09 08:19:43 --> Language Class Initialized
INFO - 2016-12-09 08:19:43 --> Loader Class Initialized
INFO - 2016-12-09 08:19:43 --> Controller Class Initialized
INFO - 2016-12-09 08:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:19:43 --> Helper loaded: form_helper
INFO - 2016-12-09 08:19:43 --> Helper loaded: url_helper
INFO - 2016-12-09 08:19:43 --> Helper loaded: html_helper
INFO - 2016-12-09 08:19:43 --> Database Driver Class Initialized
INFO - 2016-12-09 08:19:43 --> Model Class Initialized
INFO - 2016-12-09 08:19:43 --> Model Class Initialized
ERROR - 2016-12-09 08:19:43 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 08:19:43 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 08:19:43 --> File loaded: C:\xampp\htdocs\Library\application\views\admin_view.php
INFO - 2016-12-09 08:19:43 --> Final output sent to browser
DEBUG - 2016-12-09 08:19:43 --> Total execution time: 0.0768
INFO - 2016-12-09 08:21:19 --> Config Class Initialized
INFO - 2016-12-09 08:21:19 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:21:19 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:21:19 --> Utf8 Class Initialized
INFO - 2016-12-09 08:21:19 --> URI Class Initialized
INFO - 2016-12-09 08:21:19 --> Router Class Initialized
INFO - 2016-12-09 08:21:19 --> Output Class Initialized
INFO - 2016-12-09 08:21:19 --> Security Class Initialized
DEBUG - 2016-12-09 08:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:21:19 --> Input Class Initialized
INFO - 2016-12-09 08:21:19 --> Language Class Initialized
INFO - 2016-12-09 08:21:19 --> Loader Class Initialized
INFO - 2016-12-09 08:21:19 --> Controller Class Initialized
INFO - 2016-12-09 08:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:21:19 --> Helper loaded: form_helper
INFO - 2016-12-09 08:21:19 --> Helper loaded: url_helper
INFO - 2016-12-09 08:21:19 --> Helper loaded: html_helper
INFO - 2016-12-09 08:21:19 --> Database Driver Class Initialized
INFO - 2016-12-09 08:21:19 --> Model Class Initialized
INFO - 2016-12-09 08:21:19 --> Model Class Initialized
ERROR - 2016-12-09 08:21:19 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 08:21:19 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 08:21:19 --> File loaded: C:\xampp\htdocs\Library\application\views\allBook_view.php
INFO - 2016-12-09 08:21:19 --> Final output sent to browser
DEBUG - 2016-12-09 08:21:19 --> Total execution time: 0.1018
INFO - 2016-12-09 08:33:48 --> Config Class Initialized
INFO - 2016-12-09 08:33:48 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:33:48 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:33:48 --> Utf8 Class Initialized
INFO - 2016-12-09 08:33:48 --> URI Class Initialized
INFO - 2016-12-09 08:33:48 --> Router Class Initialized
INFO - 2016-12-09 08:33:48 --> Output Class Initialized
INFO - 2016-12-09 08:33:48 --> Security Class Initialized
DEBUG - 2016-12-09 08:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:33:48 --> Input Class Initialized
INFO - 2016-12-09 08:33:48 --> Language Class Initialized
INFO - 2016-12-09 08:33:48 --> Loader Class Initialized
INFO - 2016-12-09 08:33:48 --> Controller Class Initialized
INFO - 2016-12-09 08:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:33:48 --> Helper loaded: form_helper
INFO - 2016-12-09 08:33:48 --> Helper loaded: url_helper
INFO - 2016-12-09 08:33:48 --> Helper loaded: html_helper
INFO - 2016-12-09 08:33:48 --> Database Driver Class Initialized
INFO - 2016-12-09 08:33:48 --> Model Class Initialized
INFO - 2016-12-09 08:33:48 --> Model Class Initialized
ERROR - 2016-12-09 08:33:48 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 08:33:48 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 08:33:48 --> File loaded: C:\xampp\htdocs\Library\application\views\admin_view.php
INFO - 2016-12-09 08:33:48 --> Final output sent to browser
DEBUG - 2016-12-09 08:33:48 --> Total execution time: 0.0796
INFO - 2016-12-09 08:33:51 --> Config Class Initialized
INFO - 2016-12-09 08:33:51 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:33:51 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:33:51 --> Utf8 Class Initialized
INFO - 2016-12-09 08:33:51 --> URI Class Initialized
INFO - 2016-12-09 08:33:51 --> Router Class Initialized
INFO - 2016-12-09 08:33:51 --> Output Class Initialized
INFO - 2016-12-09 08:33:51 --> Security Class Initialized
DEBUG - 2016-12-09 08:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:33:51 --> Input Class Initialized
INFO - 2016-12-09 08:33:51 --> Language Class Initialized
INFO - 2016-12-09 08:33:51 --> Loader Class Initialized
INFO - 2016-12-09 08:33:51 --> Controller Class Initialized
INFO - 2016-12-09 08:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:33:51 --> Helper loaded: form_helper
INFO - 2016-12-09 08:33:51 --> Helper loaded: url_helper
INFO - 2016-12-09 08:33:51 --> Helper loaded: html_helper
INFO - 2016-12-09 08:33:51 --> Database Driver Class Initialized
INFO - 2016-12-09 08:33:51 --> Model Class Initialized
INFO - 2016-12-09 08:33:51 --> Model Class Initialized
ERROR - 2016-12-09 08:33:51 --> Severity: Error --> Call to undefined method user_model::getAllReports() C:\xampp\htdocs\Library\application\controllers\admin.php 57
INFO - 2016-12-09 08:41:54 --> Config Class Initialized
INFO - 2016-12-09 08:41:54 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:41:54 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:41:54 --> Utf8 Class Initialized
INFO - 2016-12-09 08:41:54 --> URI Class Initialized
INFO - 2016-12-09 08:41:54 --> Router Class Initialized
INFO - 2016-12-09 08:41:54 --> Output Class Initialized
INFO - 2016-12-09 08:41:54 --> Security Class Initialized
DEBUG - 2016-12-09 08:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:41:54 --> Input Class Initialized
INFO - 2016-12-09 08:41:54 --> Language Class Initialized
INFO - 2016-12-09 08:41:54 --> Loader Class Initialized
INFO - 2016-12-09 08:41:54 --> Controller Class Initialized
INFO - 2016-12-09 08:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:41:54 --> Helper loaded: form_helper
INFO - 2016-12-09 08:41:54 --> Helper loaded: url_helper
INFO - 2016-12-09 08:41:54 --> Helper loaded: html_helper
INFO - 2016-12-09 08:41:54 --> Database Driver Class Initialized
INFO - 2016-12-09 08:41:54 --> Model Class Initialized
INFO - 2016-12-09 08:41:54 --> Model Class Initialized
ERROR - 2016-12-09 08:41:54 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 08:41:54 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 08:41:54 --> File loaded: C:\xampp\htdocs\Library\application\views\admin_view.php
INFO - 2016-12-09 08:41:54 --> Final output sent to browser
DEBUG - 2016-12-09 08:41:54 --> Total execution time: 0.1122
INFO - 2016-12-09 08:41:57 --> Config Class Initialized
INFO - 2016-12-09 08:41:57 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:41:57 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:41:57 --> Utf8 Class Initialized
INFO - 2016-12-09 08:41:57 --> URI Class Initialized
INFO - 2016-12-09 08:41:57 --> Router Class Initialized
INFO - 2016-12-09 08:41:57 --> Output Class Initialized
INFO - 2016-12-09 08:41:57 --> Security Class Initialized
DEBUG - 2016-12-09 08:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:41:57 --> Input Class Initialized
INFO - 2016-12-09 08:41:57 --> Language Class Initialized
INFO - 2016-12-09 08:41:57 --> Loader Class Initialized
INFO - 2016-12-09 08:41:57 --> Controller Class Initialized
INFO - 2016-12-09 08:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:41:57 --> Helper loaded: form_helper
INFO - 2016-12-09 08:41:57 --> Helper loaded: url_helper
INFO - 2016-12-09 08:41:57 --> Helper loaded: html_helper
INFO - 2016-12-09 08:41:57 --> Database Driver Class Initialized
INFO - 2016-12-09 08:41:57 --> Model Class Initialized
INFO - 2016-12-09 08:41:57 --> Model Class Initialized
ERROR - 2016-12-09 08:41:57 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 08:41:57 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 08:41:57 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 08:41:57 --> Final output sent to browser
DEBUG - 2016-12-09 08:41:57 --> Total execution time: 0.0886
INFO - 2016-12-09 08:42:16 --> Config Class Initialized
INFO - 2016-12-09 08:42:16 --> Hooks Class Initialized
DEBUG - 2016-12-09 08:42:16 --> UTF-8 Support Enabled
INFO - 2016-12-09 08:42:16 --> Utf8 Class Initialized
INFO - 2016-12-09 08:42:16 --> URI Class Initialized
INFO - 2016-12-09 08:42:16 --> Router Class Initialized
INFO - 2016-12-09 08:42:16 --> Output Class Initialized
INFO - 2016-12-09 08:42:16 --> Security Class Initialized
DEBUG - 2016-12-09 08:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 08:42:16 --> Input Class Initialized
INFO - 2016-12-09 08:42:16 --> Language Class Initialized
INFO - 2016-12-09 08:42:16 --> Loader Class Initialized
INFO - 2016-12-09 08:42:16 --> Controller Class Initialized
INFO - 2016-12-09 08:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 08:42:16 --> Helper loaded: form_helper
INFO - 2016-12-09 08:42:16 --> Helper loaded: url_helper
INFO - 2016-12-09 08:42:16 --> Helper loaded: html_helper
INFO - 2016-12-09 08:42:16 --> Database Driver Class Initialized
INFO - 2016-12-09 08:42:16 --> Model Class Initialized
INFO - 2016-12-09 08:42:16 --> Model Class Initialized
ERROR - 2016-12-09 08:42:16 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 08:42:16 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 08:42:16 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 08:42:16 --> Final output sent to browser
DEBUG - 2016-12-09 08:42:16 --> Total execution time: 0.0708
INFO - 2016-12-09 09:19:36 --> Config Class Initialized
INFO - 2016-12-09 09:19:36 --> Hooks Class Initialized
DEBUG - 2016-12-09 09:19:36 --> UTF-8 Support Enabled
INFO - 2016-12-09 09:19:36 --> Utf8 Class Initialized
INFO - 2016-12-09 09:19:36 --> URI Class Initialized
INFO - 2016-12-09 09:19:36 --> Router Class Initialized
INFO - 2016-12-09 09:19:36 --> Output Class Initialized
INFO - 2016-12-09 09:19:36 --> Security Class Initialized
DEBUG - 2016-12-09 09:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 09:19:36 --> Input Class Initialized
INFO - 2016-12-09 09:19:36 --> Language Class Initialized
INFO - 2016-12-09 09:19:36 --> Loader Class Initialized
INFO - 2016-12-09 09:19:36 --> Controller Class Initialized
INFO - 2016-12-09 09:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 09:19:36 --> Helper loaded: form_helper
INFO - 2016-12-09 09:19:36 --> Helper loaded: url_helper
INFO - 2016-12-09 09:19:36 --> Helper loaded: html_helper
INFO - 2016-12-09 09:19:36 --> Database Driver Class Initialized
INFO - 2016-12-09 09:19:36 --> Model Class Initialized
INFO - 2016-12-09 09:19:36 --> Model Class Initialized
ERROR - 2016-12-09 09:19:36 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 09:19:36 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 09:19:36 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 09:19:36 --> Final output sent to browser
DEBUG - 2016-12-09 09:19:36 --> Total execution time: 0.0904
INFO - 2016-12-09 09:21:34 --> Config Class Initialized
INFO - 2016-12-09 09:21:34 --> Hooks Class Initialized
DEBUG - 2016-12-09 09:21:34 --> UTF-8 Support Enabled
INFO - 2016-12-09 09:21:34 --> Utf8 Class Initialized
INFO - 2016-12-09 09:21:34 --> URI Class Initialized
INFO - 2016-12-09 09:21:34 --> Router Class Initialized
INFO - 2016-12-09 09:21:34 --> Output Class Initialized
INFO - 2016-12-09 09:21:34 --> Security Class Initialized
DEBUG - 2016-12-09 09:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 09:21:34 --> Input Class Initialized
INFO - 2016-12-09 09:21:34 --> Language Class Initialized
INFO - 2016-12-09 09:21:34 --> Loader Class Initialized
INFO - 2016-12-09 09:21:34 --> Controller Class Initialized
INFO - 2016-12-09 09:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 09:21:34 --> Helper loaded: form_helper
INFO - 2016-12-09 09:21:34 --> Helper loaded: url_helper
INFO - 2016-12-09 09:21:34 --> Helper loaded: html_helper
INFO - 2016-12-09 09:21:34 --> Database Driver Class Initialized
INFO - 2016-12-09 09:21:34 --> Model Class Initialized
INFO - 2016-12-09 09:21:34 --> Model Class Initialized
ERROR - 2016-12-09 09:21:34 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 09:21:34 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 09:21:34 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 09:21:34 --> Final output sent to browser
DEBUG - 2016-12-09 09:21:34 --> Total execution time: 0.0817
INFO - 2016-12-09 09:22:33 --> Config Class Initialized
INFO - 2016-12-09 09:22:33 --> Hooks Class Initialized
DEBUG - 2016-12-09 09:22:33 --> UTF-8 Support Enabled
INFO - 2016-12-09 09:22:33 --> Utf8 Class Initialized
INFO - 2016-12-09 09:22:33 --> URI Class Initialized
INFO - 2016-12-09 09:22:33 --> Router Class Initialized
INFO - 2016-12-09 09:22:33 --> Output Class Initialized
INFO - 2016-12-09 09:22:33 --> Security Class Initialized
DEBUG - 2016-12-09 09:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 09:22:33 --> Input Class Initialized
INFO - 2016-12-09 09:22:33 --> Language Class Initialized
INFO - 2016-12-09 09:22:33 --> Loader Class Initialized
INFO - 2016-12-09 09:22:33 --> Controller Class Initialized
INFO - 2016-12-09 09:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 09:22:33 --> Helper loaded: form_helper
INFO - 2016-12-09 09:22:33 --> Helper loaded: url_helper
INFO - 2016-12-09 09:22:33 --> Helper loaded: html_helper
INFO - 2016-12-09 09:22:33 --> Database Driver Class Initialized
INFO - 2016-12-09 09:22:33 --> Model Class Initialized
INFO - 2016-12-09 09:22:33 --> Model Class Initialized
ERROR - 2016-12-09 09:22:33 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 09:22:33 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 09:22:33 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 09:22:33 --> Final output sent to browser
DEBUG - 2016-12-09 09:22:33 --> Total execution time: 0.0768
INFO - 2016-12-09 10:45:04 --> Config Class Initialized
INFO - 2016-12-09 10:45:04 --> Hooks Class Initialized
DEBUG - 2016-12-09 10:45:04 --> UTF-8 Support Enabled
INFO - 2016-12-09 10:45:04 --> Utf8 Class Initialized
INFO - 2016-12-09 10:45:04 --> URI Class Initialized
INFO - 2016-12-09 10:45:04 --> Router Class Initialized
INFO - 2016-12-09 10:45:04 --> Output Class Initialized
INFO - 2016-12-09 10:45:04 --> Security Class Initialized
DEBUG - 2016-12-09 10:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 10:45:04 --> Input Class Initialized
INFO - 2016-12-09 10:45:04 --> Language Class Initialized
INFO - 2016-12-09 10:45:04 --> Loader Class Initialized
INFO - 2016-12-09 10:45:04 --> Controller Class Initialized
INFO - 2016-12-09 10:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 10:45:04 --> Helper loaded: form_helper
INFO - 2016-12-09 10:45:04 --> Helper loaded: url_helper
INFO - 2016-12-09 10:45:04 --> Helper loaded: html_helper
INFO - 2016-12-09 10:45:04 --> Database Driver Class Initialized
INFO - 2016-12-09 10:45:05 --> Model Class Initialized
INFO - 2016-12-09 10:45:05 --> Model Class Initialized
ERROR - 2016-12-09 10:45:05 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 10:45:05 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 10:45:05 --> File loaded: C:\xampp\htdocs\Library\application\views\admin_view.php
INFO - 2016-12-09 10:45:05 --> Final output sent to browser
DEBUG - 2016-12-09 10:45:05 --> Total execution time: 0.2623
INFO - 2016-12-09 10:45:07 --> Config Class Initialized
INFO - 2016-12-09 10:45:07 --> Hooks Class Initialized
DEBUG - 2016-12-09 10:45:07 --> UTF-8 Support Enabled
INFO - 2016-12-09 10:45:07 --> Utf8 Class Initialized
INFO - 2016-12-09 10:45:07 --> URI Class Initialized
INFO - 2016-12-09 10:45:07 --> Router Class Initialized
INFO - 2016-12-09 10:45:07 --> Output Class Initialized
INFO - 2016-12-09 10:45:07 --> Security Class Initialized
DEBUG - 2016-12-09 10:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 10:45:07 --> Input Class Initialized
INFO - 2016-12-09 10:45:07 --> Language Class Initialized
INFO - 2016-12-09 10:45:07 --> Loader Class Initialized
INFO - 2016-12-09 10:45:07 --> Controller Class Initialized
INFO - 2016-12-09 10:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 10:45:07 --> Helper loaded: form_helper
INFO - 2016-12-09 10:45:07 --> Helper loaded: url_helper
INFO - 2016-12-09 10:45:07 --> Helper loaded: html_helper
INFO - 2016-12-09 10:45:07 --> Database Driver Class Initialized
INFO - 2016-12-09 10:45:07 --> Model Class Initialized
INFO - 2016-12-09 10:45:07 --> Model Class Initialized
ERROR - 2016-12-09 10:45:07 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 10:45:07 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 10:45:07 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 10:45:07 --> Final output sent to browser
DEBUG - 2016-12-09 10:45:07 --> Total execution time: 0.1116
INFO - 2016-12-09 11:09:20 --> Config Class Initialized
INFO - 2016-12-09 11:09:20 --> Hooks Class Initialized
DEBUG - 2016-12-09 11:09:20 --> UTF-8 Support Enabled
INFO - 2016-12-09 11:09:20 --> Utf8 Class Initialized
INFO - 2016-12-09 11:09:20 --> URI Class Initialized
INFO - 2016-12-09 11:09:20 --> Router Class Initialized
INFO - 2016-12-09 11:09:20 --> Output Class Initialized
INFO - 2016-12-09 11:09:20 --> Security Class Initialized
DEBUG - 2016-12-09 11:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 11:09:20 --> Input Class Initialized
INFO - 2016-12-09 11:09:20 --> Language Class Initialized
INFO - 2016-12-09 11:09:20 --> Loader Class Initialized
INFO - 2016-12-09 11:09:20 --> Controller Class Initialized
INFO - 2016-12-09 11:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 11:09:20 --> Helper loaded: form_helper
INFO - 2016-12-09 11:09:20 --> Helper loaded: url_helper
INFO - 2016-12-09 11:09:20 --> Helper loaded: html_helper
INFO - 2016-12-09 11:09:20 --> Database Driver Class Initialized
INFO - 2016-12-09 11:09:20 --> Model Class Initialized
INFO - 2016-12-09 11:09:20 --> Model Class Initialized
ERROR - 2016-12-09 11:09:20 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 11:09:20 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
ERROR - 2016-12-09 11:09:20 --> Severity: Notice --> Undefined property: stdClass::$user C:\xampp\htdocs\Library\application\views\allReport_view.php 47
ERROR - 2016-12-09 11:09:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Library\application\views\allReport_view.php 47
ERROR - 2016-12-09 11:09:20 --> Severity: Notice --> Undefined property: stdClass::$user C:\xampp\htdocs\Library\application\views\allReport_view.php 47
ERROR - 2016-12-09 11:09:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Library\application\views\allReport_view.php 47
INFO - 2016-12-09 11:09:20 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 11:09:20 --> Final output sent to browser
DEBUG - 2016-12-09 11:09:20 --> Total execution time: 0.1041
INFO - 2016-12-09 11:31:03 --> Config Class Initialized
INFO - 2016-12-09 11:31:03 --> Hooks Class Initialized
DEBUG - 2016-12-09 11:31:03 --> UTF-8 Support Enabled
INFO - 2016-12-09 11:31:03 --> Utf8 Class Initialized
INFO - 2016-12-09 11:31:03 --> URI Class Initialized
INFO - 2016-12-09 11:31:03 --> Router Class Initialized
INFO - 2016-12-09 11:31:03 --> Output Class Initialized
INFO - 2016-12-09 11:31:03 --> Security Class Initialized
DEBUG - 2016-12-09 11:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 11:31:03 --> Input Class Initialized
INFO - 2016-12-09 11:31:03 --> Language Class Initialized
INFO - 2016-12-09 11:31:03 --> Loader Class Initialized
INFO - 2016-12-09 11:31:03 --> Controller Class Initialized
INFO - 2016-12-09 11:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 11:31:03 --> Helper loaded: form_helper
INFO - 2016-12-09 11:31:03 --> Helper loaded: url_helper
INFO - 2016-12-09 11:31:03 --> Helper loaded: html_helper
INFO - 2016-12-09 11:31:03 --> Database Driver Class Initialized
INFO - 2016-12-09 11:31:03 --> Model Class Initialized
INFO - 2016-12-09 11:31:03 --> Model Class Initialized
ERROR - 2016-12-09 11:31:03 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 11:31:03 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
ERROR - 2016-12-09 11:31:03 --> Severity: Notice --> Undefined property: stdClass::$owner C:\xampp\htdocs\Library\application\views\allReport_view.php 47
ERROR - 2016-12-09 11:31:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Library\application\views\allReport_view.php 47
ERROR - 2016-12-09 11:31:03 --> Severity: Notice --> Undefined property: stdClass::$owner C:\xampp\htdocs\Library\application\views\allReport_view.php 47
ERROR - 2016-12-09 11:31:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Library\application\views\allReport_view.php 47
INFO - 2016-12-09 11:31:03 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 11:31:03 --> Final output sent to browser
DEBUG - 2016-12-09 11:31:03 --> Total execution time: 0.0845
INFO - 2016-12-09 11:32:42 --> Config Class Initialized
INFO - 2016-12-09 11:32:42 --> Hooks Class Initialized
DEBUG - 2016-12-09 11:32:42 --> UTF-8 Support Enabled
INFO - 2016-12-09 11:32:42 --> Utf8 Class Initialized
INFO - 2016-12-09 11:32:42 --> URI Class Initialized
INFO - 2016-12-09 11:32:42 --> Router Class Initialized
INFO - 2016-12-09 11:32:42 --> Output Class Initialized
INFO - 2016-12-09 11:32:42 --> Security Class Initialized
DEBUG - 2016-12-09 11:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 11:32:42 --> Input Class Initialized
INFO - 2016-12-09 11:32:42 --> Language Class Initialized
INFO - 2016-12-09 11:32:42 --> Loader Class Initialized
INFO - 2016-12-09 11:32:42 --> Controller Class Initialized
INFO - 2016-12-09 11:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 11:32:42 --> Helper loaded: form_helper
INFO - 2016-12-09 11:32:42 --> Helper loaded: url_helper
INFO - 2016-12-09 11:32:42 --> Helper loaded: html_helper
INFO - 2016-12-09 11:32:42 --> Database Driver Class Initialized
INFO - 2016-12-09 11:32:42 --> Model Class Initialized
INFO - 2016-12-09 11:32:42 --> Model Class Initialized
ERROR - 2016-12-09 11:32:42 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 11:32:42 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
ERROR - 2016-12-09 11:32:42 --> Severity: Notice --> Undefined property: stdClass::$owner C:\xampp\htdocs\Library\application\views\allReport_view.php 47
ERROR - 2016-12-09 11:32:42 --> Severity: Notice --> Use of undefined constant firstName - assumed 'firstName' C:\xampp\htdocs\Library\application\views\allReport_view.php 47
ERROR - 2016-12-09 11:32:42 --> Severity: Notice --> Undefined property: stdClass::$owner C:\xampp\htdocs\Library\application\views\allReport_view.php 47
ERROR - 2016-12-09 11:32:42 --> Severity: Notice --> Use of undefined constant lastName - assumed 'lastName' C:\xampp\htdocs\Library\application\views\allReport_view.php 47
INFO - 2016-12-09 11:32:42 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 11:32:42 --> Final output sent to browser
DEBUG - 2016-12-09 11:32:42 --> Total execution time: 0.1926
INFO - 2016-12-09 11:48:18 --> Config Class Initialized
INFO - 2016-12-09 11:48:18 --> Hooks Class Initialized
DEBUG - 2016-12-09 11:48:18 --> UTF-8 Support Enabled
INFO - 2016-12-09 11:48:18 --> Utf8 Class Initialized
INFO - 2016-12-09 11:48:18 --> URI Class Initialized
INFO - 2016-12-09 11:48:18 --> Router Class Initialized
INFO - 2016-12-09 11:48:18 --> Output Class Initialized
INFO - 2016-12-09 11:48:18 --> Security Class Initialized
DEBUG - 2016-12-09 11:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 11:48:18 --> Input Class Initialized
INFO - 2016-12-09 11:48:18 --> Language Class Initialized
INFO - 2016-12-09 11:48:18 --> Loader Class Initialized
INFO - 2016-12-09 11:48:18 --> Controller Class Initialized
INFO - 2016-12-09 11:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 11:48:18 --> Helper loaded: form_helper
INFO - 2016-12-09 11:48:18 --> Helper loaded: url_helper
INFO - 2016-12-09 11:48:18 --> Helper loaded: html_helper
INFO - 2016-12-09 11:48:18 --> Database Driver Class Initialized
INFO - 2016-12-09 11:48:18 --> Model Class Initialized
ERROR - 2016-12-09 11:48:18 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\Library\application\models\user_model.php 65
INFO - 2016-12-09 11:48:59 --> Config Class Initialized
INFO - 2016-12-09 11:48:59 --> Hooks Class Initialized
DEBUG - 2016-12-09 11:48:59 --> UTF-8 Support Enabled
INFO - 2016-12-09 11:48:59 --> Utf8 Class Initialized
INFO - 2016-12-09 11:48:59 --> URI Class Initialized
INFO - 2016-12-09 11:48:59 --> Router Class Initialized
INFO - 2016-12-09 11:48:59 --> Output Class Initialized
INFO - 2016-12-09 11:48:59 --> Security Class Initialized
DEBUG - 2016-12-09 11:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 11:48:59 --> Input Class Initialized
INFO - 2016-12-09 11:48:59 --> Language Class Initialized
INFO - 2016-12-09 11:48:59 --> Loader Class Initialized
INFO - 2016-12-09 11:48:59 --> Controller Class Initialized
INFO - 2016-12-09 11:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 11:48:59 --> Helper loaded: form_helper
INFO - 2016-12-09 11:48:59 --> Helper loaded: url_helper
INFO - 2016-12-09 11:48:59 --> Helper loaded: html_helper
INFO - 2016-12-09 11:48:59 --> Database Driver Class Initialized
INFO - 2016-12-09 11:48:59 --> Model Class Initialized
INFO - 2016-12-09 11:48:59 --> Model Class Initialized
ERROR - 2016-12-09 11:48:59 --> Query error: Unknown column 'users.userID' in 'on clause' - Invalid query: SELECT `rep`.`reportID`, `rep`.`bookID`, `rep`.`ownerID`, `rep`.`reporterID`, `rep`.`accepted`, `rep`.`reports`, `reporter`.`firstName` as `repFN`, `reporter`.`lastName` as `repLN`, `owner`.`firstName` as `ownerFN`, `owner`.`lastName` as `ownerLN`
FROM `report` as `rep`
JOIN `users` as `owner` ON `users`.`userID` = `report`.`ownerID`
LEFT JOIN `book` ON `book`.`bookID` = `report`.`bookID`
JOIN `users` as `reporter` ON `users`.`userID` = `reporterID`
INFO - 2016-12-09 11:48:59 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-09 11:54:31 --> Config Class Initialized
INFO - 2016-12-09 11:54:31 --> Hooks Class Initialized
DEBUG - 2016-12-09 11:54:31 --> UTF-8 Support Enabled
INFO - 2016-12-09 11:54:31 --> Utf8 Class Initialized
INFO - 2016-12-09 11:54:31 --> URI Class Initialized
INFO - 2016-12-09 11:54:31 --> Router Class Initialized
INFO - 2016-12-09 11:54:31 --> Output Class Initialized
INFO - 2016-12-09 11:54:31 --> Security Class Initialized
DEBUG - 2016-12-09 11:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 11:54:31 --> Input Class Initialized
INFO - 2016-12-09 11:54:31 --> Language Class Initialized
INFO - 2016-12-09 11:54:31 --> Loader Class Initialized
INFO - 2016-12-09 11:54:31 --> Controller Class Initialized
INFO - 2016-12-09 11:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 11:54:31 --> Helper loaded: form_helper
INFO - 2016-12-09 11:54:31 --> Helper loaded: url_helper
INFO - 2016-12-09 11:54:31 --> Helper loaded: html_helper
INFO - 2016-12-09 11:54:31 --> Database Driver Class Initialized
INFO - 2016-12-09 11:54:31 --> Model Class Initialized
INFO - 2016-12-09 11:54:31 --> Model Class Initialized
ERROR - 2016-12-09 11:54:31 --> Query error: Unknown column 'users.userID' in 'on clause' - Invalid query: SELECT `rep`.`reportID`, `rep`.`bookID`, `rep`.`ownerID`, `rep`.`reporterID`, `rep`.`accepted`, `rep`.`reports`, `reporter`.`firstName` as `repFN`, `reporter`.`lastName` as `repLN`, `owner`.`firstName` as `ownerFN`, `owner`.`lastName` as `ownerLN`
FROM `report` as `rep`
LEFT JOIN `users` as `owner` ON `users`.`userID` = `report`.`ownerID`
LEFT JOIN `book` ON `book`.`bookID` = `report`.`bookID`
LEFT JOIN `users` as `reporter` ON `users`.`userID` = `reporterID`
INFO - 2016-12-09 11:54:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-09 11:54:33 --> Config Class Initialized
INFO - 2016-12-09 11:54:33 --> Hooks Class Initialized
DEBUG - 2016-12-09 11:54:33 --> UTF-8 Support Enabled
INFO - 2016-12-09 11:54:33 --> Utf8 Class Initialized
INFO - 2016-12-09 11:54:33 --> URI Class Initialized
INFO - 2016-12-09 11:54:33 --> Router Class Initialized
INFO - 2016-12-09 11:54:33 --> Output Class Initialized
INFO - 2016-12-09 11:54:33 --> Security Class Initialized
DEBUG - 2016-12-09 11:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 11:54:33 --> Input Class Initialized
INFO - 2016-12-09 11:54:33 --> Language Class Initialized
INFO - 2016-12-09 11:54:33 --> Loader Class Initialized
INFO - 2016-12-09 11:54:33 --> Controller Class Initialized
INFO - 2016-12-09 11:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 11:54:33 --> Helper loaded: form_helper
INFO - 2016-12-09 11:54:33 --> Helper loaded: url_helper
INFO - 2016-12-09 11:54:33 --> Helper loaded: html_helper
INFO - 2016-12-09 11:54:33 --> Database Driver Class Initialized
INFO - 2016-12-09 11:54:33 --> Model Class Initialized
INFO - 2016-12-09 11:54:33 --> Model Class Initialized
ERROR - 2016-12-09 11:54:33 --> Query error: Unknown column 'users.userID' in 'on clause' - Invalid query: SELECT `rep`.`reportID`, `rep`.`bookID`, `rep`.`ownerID`, `rep`.`reporterID`, `rep`.`accepted`, `rep`.`reports`, `reporter`.`firstName` as `repFN`, `reporter`.`lastName` as `repLN`, `owner`.`firstName` as `ownerFN`, `owner`.`lastName` as `ownerLN`
FROM `report` as `rep`
LEFT JOIN `users` as `owner` ON `users`.`userID` = `report`.`ownerID`
LEFT JOIN `book` ON `book`.`bookID` = `report`.`bookID`
LEFT JOIN `users` as `reporter` ON `users`.`userID` = `reporterID`
INFO - 2016-12-09 11:54:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-09 11:54:36 --> Config Class Initialized
INFO - 2016-12-09 11:54:36 --> Hooks Class Initialized
DEBUG - 2016-12-09 11:54:36 --> UTF-8 Support Enabled
INFO - 2016-12-09 11:54:36 --> Utf8 Class Initialized
INFO - 2016-12-09 11:54:36 --> URI Class Initialized
INFO - 2016-12-09 11:54:36 --> Router Class Initialized
INFO - 2016-12-09 11:54:36 --> Output Class Initialized
INFO - 2016-12-09 11:54:36 --> Security Class Initialized
DEBUG - 2016-12-09 11:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 11:54:36 --> Input Class Initialized
INFO - 2016-12-09 11:54:36 --> Language Class Initialized
INFO - 2016-12-09 11:54:36 --> Loader Class Initialized
INFO - 2016-12-09 11:54:36 --> Controller Class Initialized
INFO - 2016-12-09 11:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 11:54:36 --> Helper loaded: form_helper
INFO - 2016-12-09 11:54:36 --> Helper loaded: url_helper
INFO - 2016-12-09 11:54:36 --> Helper loaded: html_helper
INFO - 2016-12-09 11:54:36 --> Database Driver Class Initialized
INFO - 2016-12-09 11:54:36 --> Model Class Initialized
INFO - 2016-12-09 11:54:36 --> Model Class Initialized
ERROR - 2016-12-09 11:54:36 --> Query error: Unknown column 'users.userID' in 'on clause' - Invalid query: SELECT `rep`.`reportID`, `rep`.`bookID`, `rep`.`ownerID`, `rep`.`reporterID`, `rep`.`accepted`, `rep`.`reports`, `reporter`.`firstName` as `repFN`, `reporter`.`lastName` as `repLN`, `owner`.`firstName` as `ownerFN`, `owner`.`lastName` as `ownerLN`
FROM `report` as `rep`
LEFT JOIN `users` as `owner` ON `users`.`userID` = `report`.`ownerID`
LEFT JOIN `book` ON `book`.`bookID` = `report`.`bookID`
LEFT JOIN `users` as `reporter` ON `users`.`userID` = `reporterID`
INFO - 2016-12-09 11:54:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-09 11:56:33 --> Config Class Initialized
INFO - 2016-12-09 11:56:33 --> Hooks Class Initialized
DEBUG - 2016-12-09 11:56:33 --> UTF-8 Support Enabled
INFO - 2016-12-09 11:56:33 --> Utf8 Class Initialized
INFO - 2016-12-09 11:56:33 --> URI Class Initialized
INFO - 2016-12-09 11:56:33 --> Router Class Initialized
INFO - 2016-12-09 11:56:33 --> Output Class Initialized
INFO - 2016-12-09 11:56:33 --> Security Class Initialized
DEBUG - 2016-12-09 11:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 11:56:33 --> Input Class Initialized
INFO - 2016-12-09 11:56:33 --> Language Class Initialized
INFO - 2016-12-09 11:56:33 --> Loader Class Initialized
INFO - 2016-12-09 11:56:33 --> Controller Class Initialized
INFO - 2016-12-09 11:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 11:56:33 --> Helper loaded: form_helper
INFO - 2016-12-09 11:56:33 --> Helper loaded: url_helper
INFO - 2016-12-09 11:56:33 --> Helper loaded: html_helper
INFO - 2016-12-09 11:56:33 --> Database Driver Class Initialized
INFO - 2016-12-09 11:56:33 --> Model Class Initialized
INFO - 2016-12-09 11:56:33 --> Model Class Initialized
ERROR - 2016-12-09 11:56:33 --> Query error: Unknown column 'report.ownerID' in 'on clause' - Invalid query: SELECT `rep`.`reportID`, `rep`.`bookID`, `rep`.`ownerID`, `rep`.`reporterID`, `rep`.`accepted`, `rep`.`reports`, `reporter`.`firstName` as `repFN`, `reporter`.`lastName` as `repLN`, `owner`.`firstName` as `ownerFN`, `owner`.`lastName` as `ownerLN`
FROM `report` as `rep`
LEFT JOIN `users` as `owner` ON `owner`.`userID` = `report`.`ownerID`
LEFT JOIN `book` ON `book`.`bookID` = `report`.`bookID`
LEFT JOIN `users` as `reporter` ON `reporter`.`userID` = `reporterID`
INFO - 2016-12-09 11:56:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-09 11:58:40 --> Config Class Initialized
INFO - 2016-12-09 11:58:40 --> Hooks Class Initialized
DEBUG - 2016-12-09 11:58:40 --> UTF-8 Support Enabled
INFO - 2016-12-09 11:58:40 --> Utf8 Class Initialized
INFO - 2016-12-09 11:58:40 --> URI Class Initialized
INFO - 2016-12-09 11:58:40 --> Router Class Initialized
INFO - 2016-12-09 11:58:40 --> Output Class Initialized
INFO - 2016-12-09 11:58:40 --> Security Class Initialized
DEBUG - 2016-12-09 11:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 11:58:40 --> Input Class Initialized
INFO - 2016-12-09 11:58:40 --> Language Class Initialized
INFO - 2016-12-09 11:58:40 --> Loader Class Initialized
INFO - 2016-12-09 11:58:40 --> Controller Class Initialized
INFO - 2016-12-09 11:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 11:58:40 --> Helper loaded: form_helper
INFO - 2016-12-09 11:58:40 --> Helper loaded: url_helper
INFO - 2016-12-09 11:58:40 --> Helper loaded: html_helper
INFO - 2016-12-09 11:58:40 --> Database Driver Class Initialized
INFO - 2016-12-09 11:58:40 --> Model Class Initialized
INFO - 2016-12-09 11:58:40 --> Model Class Initialized
ERROR - 2016-12-09 11:58:40 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 11:58:40 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
ERROR - 2016-12-09 11:58:40 --> Severity: Notice --> Undefined property: stdClass::$coverImg C:\xampp\htdocs\Library\application\views\allReport_view.php 40
ERROR - 2016-12-09 11:58:40 --> Severity: Notice --> Undefined property: stdClass::$bookName C:\xampp\htdocs\Library\application\views\allReport_view.php 46
INFO - 2016-12-09 11:58:40 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 11:58:40 --> Final output sent to browser
DEBUG - 2016-12-09 11:58:40 --> Total execution time: 0.0806
INFO - 2016-12-09 11:59:06 --> Config Class Initialized
INFO - 2016-12-09 11:59:06 --> Hooks Class Initialized
DEBUG - 2016-12-09 11:59:06 --> UTF-8 Support Enabled
INFO - 2016-12-09 11:59:06 --> Utf8 Class Initialized
INFO - 2016-12-09 11:59:06 --> URI Class Initialized
INFO - 2016-12-09 11:59:06 --> Router Class Initialized
INFO - 2016-12-09 11:59:06 --> Output Class Initialized
INFO - 2016-12-09 11:59:06 --> Security Class Initialized
DEBUG - 2016-12-09 11:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 11:59:06 --> Input Class Initialized
INFO - 2016-12-09 11:59:06 --> Language Class Initialized
INFO - 2016-12-09 11:59:06 --> Loader Class Initialized
INFO - 2016-12-09 11:59:06 --> Controller Class Initialized
INFO - 2016-12-09 11:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 11:59:06 --> Helper loaded: form_helper
INFO - 2016-12-09 11:59:06 --> Helper loaded: url_helper
INFO - 2016-12-09 11:59:06 --> Helper loaded: html_helper
INFO - 2016-12-09 11:59:06 --> Database Driver Class Initialized
INFO - 2016-12-09 11:59:06 --> Model Class Initialized
INFO - 2016-12-09 11:59:06 --> Model Class Initialized
ERROR - 2016-12-09 11:59:06 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 11:59:06 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
ERROR - 2016-12-09 11:59:06 --> Severity: Notice --> Undefined property: stdClass::$coverImg C:\xampp\htdocs\Library\application\views\allReport_view.php 40
ERROR - 2016-12-09 11:59:06 --> Severity: Notice --> Undefined property: stdClass::$bookName C:\xampp\htdocs\Library\application\views\allReport_view.php 46
INFO - 2016-12-09 11:59:06 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 11:59:06 --> Final output sent to browser
DEBUG - 2016-12-09 11:59:06 --> Total execution time: 0.0794
INFO - 2016-12-09 12:00:54 --> Config Class Initialized
INFO - 2016-12-09 12:00:54 --> Hooks Class Initialized
DEBUG - 2016-12-09 12:00:54 --> UTF-8 Support Enabled
INFO - 2016-12-09 12:00:54 --> Utf8 Class Initialized
INFO - 2016-12-09 12:00:54 --> URI Class Initialized
INFO - 2016-12-09 12:00:54 --> Router Class Initialized
INFO - 2016-12-09 12:00:54 --> Output Class Initialized
INFO - 2016-12-09 12:00:54 --> Security Class Initialized
DEBUG - 2016-12-09 12:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-09 12:00:54 --> Input Class Initialized
INFO - 2016-12-09 12:00:54 --> Language Class Initialized
INFO - 2016-12-09 12:00:54 --> Loader Class Initialized
INFO - 2016-12-09 12:00:54 --> Controller Class Initialized
INFO - 2016-12-09 12:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-09 12:00:54 --> Helper loaded: form_helper
INFO - 2016-12-09 12:00:54 --> Helper loaded: url_helper
INFO - 2016-12-09 12:00:54 --> Helper loaded: html_helper
INFO - 2016-12-09 12:00:54 --> Database Driver Class Initialized
INFO - 2016-12-09 12:00:54 --> Model Class Initialized
INFO - 2016-12-09 12:00:54 --> Model Class Initialized
ERROR - 2016-12-09 12:00:54 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\Library\application\views\header_view.php 109
INFO - 2016-12-09 12:00:54 --> File loaded: C:\xampp\htdocs\Library\application\views\header_view.php
INFO - 2016-12-09 12:00:54 --> File loaded: C:\xampp\htdocs\Library\application\views\allReport_view.php
INFO - 2016-12-09 12:00:54 --> Final output sent to browser
DEBUG - 2016-12-09 12:00:54 --> Total execution time: 0.0798
