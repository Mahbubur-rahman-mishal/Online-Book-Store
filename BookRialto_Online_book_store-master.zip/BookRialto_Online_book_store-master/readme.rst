###################
What is Bookrialto
###################
It's a online bookstore where you can upload your books and share with your friends.
Developement Enviroment:
  1) Codeigniter 3 (PHP Framework)
  2) MySql
  3) Jquery Ajax
